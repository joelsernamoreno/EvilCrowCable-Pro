#  TinyUSB Mouse and Keyboard Library Changelog

## 0.1.2 - 20 20.04.26

- Merged PR #1

## 0.1.1 - 2020.04.17

- Complete Redesign to combine mouse and keyboard in the same library

## 0.1.0 - 2020.04.14

- Initial beta release
